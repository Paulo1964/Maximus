import xbmcaddon

MainBase = 'aqui metes o teu link'
addon = xbmcaddon.Addon('plugin.video.koditugaddon')